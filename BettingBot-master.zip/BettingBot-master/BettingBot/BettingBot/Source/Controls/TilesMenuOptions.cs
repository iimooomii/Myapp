﻿using System.Collections.ObjectModel;

namespace BettingBot.Source.Controls
{
    public class TilesMenuOptions : ObservableCollection<TilesMenuOption>
    {
        //override Add 
    }
}
