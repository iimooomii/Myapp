﻿using System;

namespace BettingBot.Source.Clients.Selenium.Asianodds
{
    public class AsianoddsSeleniumDriverManager : SeleniumDriverManager
    {

    }
}
