﻿namespace BettingBot.Source.Clients
{
    public abstract class ResponseBase : InformationSender
    {
    }
}
